let cash = 0
let cps = 0
let upgrade1 = 0
let upgrade1Next = 10
let upgrade2 = 0
let upgrade2Next = 1000

function Cash() {
    cash += 1
}

function upgrade() {
    if (cash >= upgrade1Next) {
        cash -= upgrade1Next
        upgrade1 += 1
        cps += 1
        upgrade1Next = upgrade1Next * 1.2
        document.getElementById("upgrade1").innerHTML = "$" + Math.ceil(upgrade1Next) + " - 1Cps";
    }
    console.log();
}

function upgrade_2() {
    if (cash >= upgrade2Next) {
        cash -= upgrade2Next
        upgrade2 += 1
        cps += 10
        upgrade2Next = upgrade2Next * 1.2
        document.getElementById("upgrade2").innerHTML = "$" + Math.ceil(upgrade2Next) + " - 10Cps";
    }
}

function tick() {
    cash += cps /10
    console.log("tick")
    document.getElementById("Cps").innerHTML = "Cps: " + Math.ceil(cps);
    document.getElementById("Counter").innerHTML = "Cash: " + Math.ceil(cash);
}

setInterval(tick, 100);